Node attributes:	[histo1, histo2, histo3, histo4, histo5, histo6, histo7, histo8, histo9, histo10, histo11, histo12, histo13, histo14, histo15, histo16, histo17, histo18, histo19, histo20, histo21, histo22, histo23, histo24, histo25, histo26, histo27, histo28, histo29, histo30, histo31, histo32, histo33, histo34, histo35, histo36, histo37, histo38, histo39, histo40, histo41, histo42, histo43, histo44, histo45, histo46, histo47, histo48, histo49, histo50, histo51, histo52, histo53, histo54, histo55, histo56, histo57, histo58, histo59, histo60, histo61, histo62, histo63, histo64]

Edge attributes:	[boundary]

